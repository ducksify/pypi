#!/usr/bin/env python
import boto3

import argparse


parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group(required=True)
group.add_argument('--bucket', help='Bucket name')
parser.add_argument('--delete', action='store_true', help='Delete Bucket')
group.add_argument('--wildcard', help='Delete Bucket and Bucket content regarding a wildcard')
args = parser.parse_args()


def start():
  s3 = boto3.resource('s3')
  if args.wildcard:
    s3cli = boto3.client('s3')
    counter = 0
    response = s3cli.list_buckets()
    for bucket in response['Buckets']:
      if args.wildcard in  bucket['Name']:
        counter+=1
        bucket = s3.Bucket(bucket['Name'])
        bucket.object_versions.delete()
        if args.delete:
          bucket.delete()
    if args.delete:
      print(f"{counter} buckets deleted")
    else:
      print(f"{counter} buckets cleared")
  else:
    bucket = s3.Bucket(args.bucket)
    bucket.object_versions.delete()
    print(f"{args.bucket} buckets cleared")

    if args.delete:
      bucket.delete()
      print(f"{args.bucket} buckets deleted")
